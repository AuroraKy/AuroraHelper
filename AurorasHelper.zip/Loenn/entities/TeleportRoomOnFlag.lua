local entity = {}

entity.name = "AurorasHelper/TeleportRoomOnFlag"

entity.placements = {
    name = "TeleportRoomOnFlag",
    data = {
        width = 8,
        height = 8,
        Flag = "",
        NewRoom = ""
    }
}

return entity