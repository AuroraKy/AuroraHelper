local entity = {}

entity.name = "AurorasHelper/InternetMemorial"
entity.texture = "scenery/memorial/memorial"
entity.depth = 100
entity.justification = {0.5, 1.0}
entity.placements = {
    name = "InternetMemorial",
    data = {
        pastebinLink = "PutF8qFd",
        sprite = "scenery/memorial/memorial",
    }
}

return entity