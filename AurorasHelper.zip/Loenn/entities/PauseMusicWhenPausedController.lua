local entity = {}

entity.name = "AurorasHelper/PauseMusicWhenPausedController"
entity.texture = "controllers/AurorasHelper/PauseMusicWhenPausedController"

entity.placements = {
    name = "PauseMusicWhenPausedController",
    data = {
        MapWide = true
    }
}


return entity