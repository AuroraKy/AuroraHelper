local entity = {}

entity.name = "AurorasHelper/HorizontalCollisionDeathController"
entity.depth = 0
entity.texture = "controllers/AurorasHelper/HorizontalCollisionDeathController"
entity.justification = {0.5, 1.0}

entity.placements = {
    name = "HorizontalCollisionDeathController",
    data = {
    }
}

return entity