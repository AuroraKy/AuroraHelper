local entity = {}

entity.name = "AurorasHelper/MusicSyncSpawnController"

entity.placements = {
    name = "MusicSyncSpawnController",
    data = {
        width = 16,
        height = 16
    }
}


return entity