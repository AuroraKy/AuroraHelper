local trigger = {}

trigger.name = "AurorasHelper/ForcedMovementTrigger"
trigger.placements = {
    name = "ForcedMovementTrigger",
    data = {
        Right = true,
        Presistent = true,
        ImmediatelyOnRespawn = false,
        Speed = 90,
    }
}


return trigger