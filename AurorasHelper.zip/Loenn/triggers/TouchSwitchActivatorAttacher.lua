local trigger = {}

trigger.name = "AurorasHelper/TouchSwitchActivatorAttacher"
trigger.placements = {
    name = "TouchSwitchActivatorAttacher",
    data = {
        width = 8,
        height = 8
    }
}

return trigger
