local trigger = {}

trigger.name = "AurorasHelper/ShowSubtitlesTrigger"
trigger.placements = {
    name = "ShowSubtitlesTrigger",
    data = {
        Path = "",
        RequiredFlags = "",
        DialogText = "",
        DialogTime = 0.0,
        Queue = false,
    }
}

return trigger